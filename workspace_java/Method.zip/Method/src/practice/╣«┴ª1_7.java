package practice;

public class 문제1_7 {
  public static void main(String[] args) {
    test7("test", "7");
  }


  //7.두 문자열을 매개변수로 받아, 두 문자열의 나열결과를 출력하는 메소드를 선언하고 호출해보세요
  public static void test7(String str1, String str2){
    System.out.println(str1 + str2);
  }
}
