package practice;

public class 문제1_4to6 {
  public static void main(String[] args) {
    //6번 문제 출력
    test6(10, 2);
    //5번 문제 출력
    //printMul(2, 2, 2);

    //4번 문제 출력
    //printSum(10, 20);

  }

  //6.두 정수를 매개변수로 받아, 두 정수의 나눗셈 몫과 나머지를 출력하는 메소드를 선언하고 호출해보세요.
  public static void test6(int num1, int num2){
    System.out.println(num1 / (double)(num2));
  }

  //5. 정수 세 개를 매개변수로 받아, 세 수의 곱을 출력하는 메소드를 선언하고 호출해 보세요.
  //public static void printMul(int num1, int num2, int num3){
  //  System.out.println(num1 * num2 * num3);
  //}

  //4. 정수 두 개를 매개변수로 받아, 두 수의 합을 출력하는 메소드를 선언하고 호출해 보세요.
  // public static void printSum(int num1, int num2){
  //  System.out.println(num1 + num2);
  //}


}
